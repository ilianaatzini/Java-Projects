package com.example.service;

import com.example.entity.Share;

public interface ShareService {
    public Share searchShareById(int shareId);
}
