package com.example.laura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShareServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
