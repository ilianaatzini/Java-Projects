package employeeTreeSetPractise;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Getter
@Setter

public class Employee implements Comparable<Employee>{
	private int id;
	private String name;
	private int yearsOfExp;
	private String designations;
	private String department;
	private double salary;
	
	//Comparabke Interface
	public int compareTo(Employee employee2) {
		if(yearsOfExp>employee2.yearsOfExp)
			return 1;
		else if (yearsOfExp<employee2.yearsOfExp)
			return -1;
		else if (this.equals(employee2))
			return 0;
		return 1;
	}

}
