package employeeTreeSetPractise;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class EmployeeTreeSetPractiseMain {
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		Set<Employee> emp = new TreeSet<>();
		
		System.out.println("Size: " + emp.size());
		int i=0;
		
		while (i<5) {
			System.out.println("Please provide Employee ID: ");
			int empId = keyboard.nextInt();
			
			System.out.println("Please provide Employee Name: ");
			String name = keyboard.next();
			
			System.out.println("Please provide Employee Years of Experience: ");
			int yOfExp = keyboard.nextInt();
			
			System.out.println("Please provide Employee Designations: ");
			String design = keyboard.next();
			
			System.out.println("Please provide Employee Department: ");
			String department = keyboard.next();
			
			System.out.println("Please provide Employee Salary: ");
			double salary = keyboard.nextDouble();
			
			emp.add(new Employee(empId, name, yOfExp, design, department, salary));
			
			i++;
		}
		
		System.out.println(emp.toString());
		
	}

}
