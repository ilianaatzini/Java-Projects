package collectionPractise;

public class NumberException extends Exception{
	public NumberException (String message) {
		super(message);
	}
}
