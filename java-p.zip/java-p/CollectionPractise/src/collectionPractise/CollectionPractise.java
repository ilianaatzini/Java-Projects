package collectionPractise;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class CollectionPractise {
	
	public static void main(String [] args) throws NumberException {
		Scanner keyboard = new Scanner(System.in);
		Set<Number> hashSetNum = new LinkedHashSet<>();
		
		int myIndex = 1;
		while (myIndex <= 10) {
			System.out.print("Please enter a number: ");
			int myNum = keyboard.nextInt();
			Number number = new Number(myNum, myIndex);
			for (Number i: hashSetNum) {
				if (i.getNum() == myNum) {
					throw new NumberException("Duplicated Number Entered!");
				}
			}
			hashSetNum.add(number);
			myIndex++;
			
		}
		for (Number j: hashSetNum) {
			System.out.println("Number: "+ j.getNum() + " | Index: " + j.getIndex());
		}
	}
}
